module Radix where
  
data Tree a = Empty | Leaf a | Node a (Tree a) (Tree a)
            deriving (Eq, Show)

type IntTree = Tree Int

type RadixTree = Tree Bool

type BitString = [Int]

--------------------------------------------------------------------------

buildIntTree :: [Int] -> IntTree
buildIntTree
  = foldr add Empty
  where
    add x Empty
      = Leaf x
    add x (Leaf y)
      = add x (Node y Empty Empty)
    add x t@(Node y l r)
      | x == y    = t
      | x < y     = Node y (add x l) r
      | otherwise = Node y l (add x r)

--------------------------------------------------------------------------

a, m :: Integer
m = 1073741824
a = 16387

rand :: Integer -> [Double]
rand s
  = fromInteger s / fromInteger m : rand s' where s' = (s * a) `mod` m

randomInts :: Int -> Int -> Integer -> [Int]
randomInts m n s
  = take m (map (round . (+1) . (* (fromIntegral n))) (rand s))

rs :: [Int]
rs = randomInts 1000 500 765539

--------------------------------------------------------------------------
-- Pre (universal): all integers are non-negative

size :: IntTree -> Int
size Empty        = 1
size (Leaf _)     = 5 
size (Node x l r) = 13 + (size l) + (size r)

size' :: RadixTree -> Int
size' (Leaf _)     = 1
size' (Node x l r) = 9 + (size' l) + (size' r)

binary' :: Int -> Int
binary' x 
  | x < 2     = x
  | otherwise = (mod x 2) + 10 * binary' (div x 2)

binary :: Int -> BitString
binary number
  | number < 0 = [0]
  | number < 2 = [number]
  | otherwise  = binary (div number 2) ++ [mod number 2]

insert :: BitString -> RadixTree -> RadixTree
insert [] (Leaf x)     = Leaf True
insert [] (Node n l r) = (Node True l r)
insert (x : xs) (Leaf n)
  | x == 1 = (Node n (Leaf False) (insert xs (Leaf False)))
  | x == 0 = (Node n (insert xs (Leaf False)) (Leaf False))
insert (x : xs) (Node n l r)
  | x == 1 = (Node n l (insert xs r))
  | x == 0 = (Node n (insert xs l) r)

buildRadixTree :: [Int] -> RadixTree
buildRadixTree [] = Leaf False
buildRadixTree (x:xs) = (insert (binary x) (buildRadixTree xs))

member :: Int -> RadixTree -> Bool
member x tree = member' (binary x) tree
  where
    member' :: BitString -> RadixTree -> Bool
    member' [] (Leaf n)     = n
    member' [] (Node n l r) = n
    member' (x:xs) (Leaf n) = False
    member' (x:xs) (Node n l r)
      | x == 1 = member' xs r
      | x == 0 = member' xs l

union :: RadixTree -> RadixTree -> RadixTree
union tree tree'
  = buildRadixTree [k | k <- [1.. (2 ^ (max (level tree) (level tree')) - 1)], (member k tree || member k tree')]
              
intersection :: RadixTree -> RadixTree -> RadixTree
intersection tree tree'
  = buildRadixTree [k | k <- [1.. (2 ^ (min (level tree) (level tree')) - 1)], (member k tree && member k tree')]

-- Helper funcion for Union and Intersection
level :: RadixTree -> Int
level (Leaf False) = 0
level (Leaf True)  = 1
level (Node _ l r) = 1 + max (level l) (level r)

              


-- CONCLUSION: The break-even point is 205.

-----------------------------------------------------------------------------
-- Some test trees...

figure :: RadixTree
figure
  = Node False (Leaf True)
               (Node True (Leaf False)
                          (Node True (Node False (Leaf True)
                                                 (Leaf False))
                                     (Leaf True)))

t1 :: IntTree
t1 = Node 20 (Node 8 Empty
                     (Node 12 Empty
                              Empty))
             Empty

t2 :: RadixTree
t2 = Node False (Node False (Leaf True)
                            (Node True (Leaf False) (Leaf True)))
                (Leaf True)

