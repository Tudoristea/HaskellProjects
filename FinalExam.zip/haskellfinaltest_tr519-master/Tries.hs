module Tries where

import Data.List hiding (insert)
import Data.Bits

import Types
import HashFunctions
import Examples

--------------------------------------------------------------------
-- Part I

-- Use this if you're counting the number of 1s in every
-- four-bit block...
bitTable :: [Int]
bitTable
  = [0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4]

countOnes :: Int -> Int
countOnes n
  | n < 2 = n
  | otherwise = (mod n 2) + countOnes (div n 2)
-- or using the bitTable with !! 

countOnesFrom :: Int -> Int -> Int
countOnesFrom i n
  = countOnes ((bit i - 1) .&. n)

getIndex :: Int -> Int -> Int -> Int
getIndex n blockNr blockSize
  = (bit blockSize - 1) .&. (shiftR n (blockSize * blockNr) )

-- Pre: the index is less than the length of the list
replace :: Int -> [a] -> a -> [a]
replace _ [] _ = []
replace i set@(c : cs) val
  | i == 0    = val : (replace (i-1) cs val)
  | otherwise = c : (replace (i-1) cs val)

-- Pre: the index is less than or equal to the length of the list
insertAt :: Int -> a -> [a] -> [a]
insertAt i val [] = val : []
insertAt i val (c:cs) 
   | i == 0    = val : (c : cs) 
   | otherwise = c : insertAt (i-1) val cs 

--------------------------------------------------------------------
-- Part II

sumTrie :: (Int -> Int) -> ([Int] -> Int) -> Trie -> Int
sumTrie f1 f2 (Leaf is) = f2 is
sumTrie f1 f2 (Node bV []) = 0
sumTrie f1 f2 (Node bV ((Term i):sNs)) 
  = (f1 i) + (sumTrie f1 f2 (Node bV sNs))
sumTrie f1 f2 (Node bV ((SubTrie t):sNs)) 
  = (sumTrie f1 f2 t) + (sumTrie f1 f2 (Node bV sNs))




-- sumTrie f1 f2 (Term i)  = f1 i 
-- sumTrie f1 f2 (Leaf is) = f2 is
-- sumTrie f1 f2 (Node _ sn ) = sum (map (sumTrie f1 f2) sN)
-- sumTrie f1 f2 (SubTrie tr) = sumTrie f1 f2 tr


trieSize :: Trie -> Int
trieSize t
  = sumTrie (const 1) length t

binCount :: Trie -> Int
binCount t
  = sumTrie (const 1) (const 1) t

meanBinSize :: Trie -> Double
meanBinSize t
  = fromIntegral (trieSize t) / fromIntegral (binCount t)

-- the function respects the description of search found in the notes
-- getIndex bV (getIndex valHash lvl blSz) 1 == 1 checks if 
                -- the given node may contain our value
-- I know used1 and 2 don't look amazing but used them to 
         -- keep the character limit
member :: Int -> Hash -> Trie -> Int -> Bool
member val' valHash' trie' blSz'
  = member' val' valHash' trie' blSz' 0
    where
      member' :: Int -> Hash -> Trie -> Int -> Int -> Bool
      member' val valHash (Leaf vals) blSz lvl
        | elem val vals = True
        | otherwise     = False
      member' val valHash (Node bV ((Term termInt):sN)) blSz lvl
        | (getIndex bV (getIndex valHash lvl blSz) 1 == 1) && termInt == val 
           = True
        | (getIndex bV (getIndex valHash lvl blSz) 1 == 1) 
           = member' val valHash (Node bV sN) blSz lvl
        | otherwise = False 
      member' val valHash (Node bV ((SubTrie sTrie):sN)) blSz lvl
        | (getIndex bV (getIndex valHash lvl blSz) 1 == 1) 
           = used1 || used2
        | otherwise = False
          where
            used1 = member' val valHash sTrie blSz (lvl + 1)
            used2 = member' val valHash (Node bV sN) blSz lvl

-------------------------------------------------------------------------------
-- Part III

insert :: HashFun -> Int -> Int -> Int -> Trie -> Trie
insert
  = undefined

buildTrie :: HashFun -> Int -> Int -> [Int] -> Trie
buildTrie
  = undefined
